import React from 'react';
import logo from './Images/logo.png'; // Supondo que o logo esteja no diretório src
import 'bootstrap/dist/css/bootstrap.min.css';
import './index.css';

function Header() {
  return (
    <header className="header-assistive">
      <div className="container d-flex justify-content-between align-items-center">
        <div className="logo">
          <img src={logo} alt="CSec Solutions Logo" />
        </div>
        <nav className="d-flex">
          <ul className="list-unstyled d-flex mb-0">
            <li className="mx-3"><a href="#home" className="text-light">Home</a></li>
            <li className="mx-3"><a href="#services" className="text-light">Serviços</a></li>
            <li className="mx-3"><a href="#about" className="text-light">Sobre a CSec Solutions</a></li>
            <li className="mx-3"><a href="#careers" className="text-light">Carreiras</a></li>
            <li className="mx-3"><a href="#contact" className="text-light">Contato</a></li>
          </ul>
        </nav>
        <div className="d-flex">
          <a href="#search" className="text-light mx-2"><i className="bi bi-search"></i></a>
          <a href="#" className="text-light mx-2">Brazil <i className="bi bi-chevron-down"></i></a>
        </div>
      </div>
    </header>
  );
}

export default Header;