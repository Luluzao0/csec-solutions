import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './index.css';

function HomePage() {
  return (
    <div className="homepage full-height">
      <div className="homepage-content text-center">
        <h1>CSec Solutions</h1>
      </div>
    </div>
  );
}

export default HomePage;